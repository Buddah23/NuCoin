# litecoin.org

## Updating Download Urls

data/software

## Dev environment
Requires Hugo (gohugo.io) v0.17


- npm i
- npm start
- hugo serve

Run hugo and npm start at the same time. Gulp compiles sass and Hugo renders and serves the page.
